<?php

return [
    // 加解密用盐
    'salt' => 'cRwKiv8l5yXBr3LVdpXs',
    // 人气:金豆
    'changeRate' => 1,
    // 偷取数额
    'stealCount' => 5,
    // 邀请奖励
    'invitAward' => [
        'coin' => 500,
        'stone' => 2
    ],
    // 偷花倒计时
    'stealLimitTime' => 120,
    // 精灵结算最大时间 
    'spriteLimitTime' => 8 * 3600,
    'appname' => '我们的偶像',
];