<?php
namespace app\base\model;

class Appinfo extends Base
{ }
