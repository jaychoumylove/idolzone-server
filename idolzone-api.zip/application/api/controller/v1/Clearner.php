<?php
namespace app\api\controller\v1;

use app\base\controller\Base;

class Clearner extends Base{

    
}