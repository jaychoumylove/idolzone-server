<?php

namespace app\api\model;

use app\base\model\Base;

class History extends Base
{
    //
}
