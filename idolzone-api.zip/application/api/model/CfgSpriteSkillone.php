<?php

namespace app\api\model;

use app\base\model\Base;

class CfgSpriteSkillone extends Base
{
    //
}
