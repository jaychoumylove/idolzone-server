<?php

namespace app\api\model;

use app\base\model\Base;

class WxImg extends Base
{
    //
}
