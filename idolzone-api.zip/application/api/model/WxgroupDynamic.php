<?php

namespace app\api\model;

use app\base\model\Base;
use think\Model;

class WxgroupDynamic extends Base
{
    
}
