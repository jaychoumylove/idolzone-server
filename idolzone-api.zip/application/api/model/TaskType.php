<?php

namespace app\api\model;

use think\Model;
use app\base\model\Base;

class TaskType extends Base
{
    //
}
