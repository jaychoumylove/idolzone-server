<?php

namespace app\api\model;

use app\base\model\Base;

class RecWeibo extends Base
{
    //
}
