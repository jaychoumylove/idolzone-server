<?php

namespace app\api\model;


class OtherLock extends Base
{
    //
}
