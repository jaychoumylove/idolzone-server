<?php

namespace app\api\model;

use app\base\model\Base;

class CfgItem extends Base
{
    //
}
