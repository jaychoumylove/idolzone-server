<?php
namespace app\api\model;

use app\base\model\Base;

class Banner extends Base{

}