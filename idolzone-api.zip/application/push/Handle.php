<?php
vendor('aliyun.SignatureHelper');